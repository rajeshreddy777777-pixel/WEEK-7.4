# OOPS Through Java Lab 4.1 — Producer-Consumer Problem

## AIM
Implement the Producer-Consumer problem using a shared `LinkedList`, synchronization, and inter-thread communication with `wait()` and `notify()`.

## Source file
- `ProducerConsumer.java`

## Algorithm
1. Create a shared `LinkedList<Integer>` with capacity 2.
2. In `produce()`, wait while the buffer is full; otherwise add the next item and notify the consumer.
3. In `consume()`, wait while the buffer is empty; otherwise remove an item and notify the producer.
4. Use `synchronized` to protect shared-buffer operations.
5. Start producer and consumer threads in `main()`.

## Compile and run
```bash
javac ProducerConsumer.java
java ProducerConsumer
```

The program runs indefinitely. Stop it with **Ctrl+C** in the terminal. The order of producer/consumer messages can vary depending on thread scheduling.
